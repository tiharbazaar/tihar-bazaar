# Tihar Bazaar — iOS App (v1.0)

Ye iPhone/iPad app hai jo live website kholti hai:
`https://tiharbazaar.github.io/tihar-bazaar/`

Website me jo change karoge, app me khud aa jayega. Internet na ho to bundled copy khulti hai.

## Files
- `TiharBazaar/ViewController.swift` — main app code (WebView + login handling)
- `TiharBazaar/AppDelegate.swift`, `SceneDelegate.swift` — app lifecycle
- `TiharBazaar/Info.plist` — app settings (bundle id: com.tyoharbazaar.app)

## App Store par dalne ke steps

### Step 1 — Apple Developer account ($99/saal)
- https://developer.apple.com/programs/ par apni Apple ID se enroll karo
- Ye tumhe khud karna hoga (identity verification hota hai)
- Bina iske App Store par app nahi ja sakti

### Step 2 — Mac par Xcode me project banao
- Mac par Xcode kholo > New Project > iOS App > naam "Tihar Bazaar", bundle id `com.tyoharbazaar.app`
- Upar wali 4 files ko project me add karo (purani files replace karke)
- Offline backup ke liye: website ki `index.html` + `assets` + `privacy.html` ko Xcode me `www` folder ke naam se add karo ("Create folder references" chunna)

### Step 3 — Build aur upload
- Apna Apple Developer account Xcode me sign in karo
- Product > Archive > Distribute App > App Store Connect
- Fir https://appstoreconnect.apple.com par app ka naam, description, screenshots dalo aur review ke liye bhejo

### Step 4 — Mac nahi hai to
- Kisi dost ka Mac use karo, ya
- MacInCloud / Codemagic jaise cloud Mac service (paise lagte hain)

## Zaroori chetavni
Apple sirf-website wali apps ko kabhi-kabhi **reject** kar deta hai (rule 4.2).
Review pass karne ke liye app me kuch native features hone chahiye (jaise push notifications).
Agar reject ho to batana — native features add kar dunga.
