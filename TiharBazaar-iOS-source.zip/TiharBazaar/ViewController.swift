import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate {

    // v1.0: the app loads the LIVE website — one edit on the site updates the app too.
    // Bundled copy (www/index.html) is the offline fallback.
    private let liveURL = URL(string: "https://tiharbazaar.github.io/tihar-bazaar/")!
    private let siteHost = "tiharbazaar.github.io"
    private let internalHosts: Set<String> = [
        "tiharbazaar.github.io",
        "tihar-bazaar.firebaseapp.com",
        "accounts.google.com",
        "facebook.com"
    ]

    private var webView: WKWebView!
    private var triedLocalFallback = false

    override func viewDidLoad() {
        super.viewDidLoad()
        setupWebView()
        loadLive()
    }

    private func setupWebView() {
        let config = WKWebViewConfiguration()
        config.preferences.javaScriptEnabled = true
        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.navigationDelegate = self
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(webView)
    }

    private func loadLive() {
        triedLocalFallback = false
        webView.load(URLRequest(url: liveURL))
    }

    private func loadLocalFallback() {
        triedLocalFallback = true
        if let localURL = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "www") {
            webView.loadFileURL(localURL, allowingReadAccess: localURL.deletingLastPathComponent())
        }
    }

    private func isInternalHost(_ host: String?) -> Bool {
        guard let host = host else { return false }
        if internalHosts.contains(host) { return true }
        if host.hasSuffix(".facebook.com") { return true }
        return false
    }

    // MARK: - WKNavigationDelegate

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow); return
        }
        let scheme = url.scheme ?? ""
        if scheme == "mailto" || scheme == "tel" {
            UIApplication.shared.open(url)
            decisionHandler(.cancel); return
        }
        if scheme == "http" || scheme == "https" {
            let host = url.host ?? ""
            // WhatsApp order links: open the WhatsApp app
            if host == "wa.me" || host.hasSuffix(".wa.me") || host == "api.whatsapp.com" {
                UIApplication.shared.open(url)
                decisionHandler(.cancel); return
            }
            // Our site + login pages stay inside the app
            if isInternalHost(url.host) {
                decisionHandler(.allow); return
            }
            // Everything else opens in Safari
            UIApplication.shared.open(url)
            decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!,
                 withError error: Error) {
        // Live site failed (e.g. offline) — fall back to the bundled copy once.
        if !triedLocalFallback {
            loadLocalFallback()
        }
    }
}
